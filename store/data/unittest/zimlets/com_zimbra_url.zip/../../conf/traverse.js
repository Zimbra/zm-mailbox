do something bad
